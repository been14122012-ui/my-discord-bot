import {
  Client,
  Events,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
} from "discord.js";

const token = process.env.DISCORD_TOKEN;

if (!token) {
  throw new Error("DISCORD_TOKEN is missing. Add it to Replit Secrets.");
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

const commands = [
  new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Kiểm tra bot có đang hoạt động không"),
  new SlashCommandBuilder()
    .setName("hello")
    .setDescription("Bot gửi lời chào"),
].map((command) => command.toJSON());

client.once(Events.ClientReady, async (readyClient) => {
  console.log(`Đã đăng nhập Discord bằng tài khoản ${readyClient.user.tag}`);

  try {
    const rest = new REST({ version: "10" }).setToken(token);
    await rest.put(Routes.applicationCommands(readyClient.user.id), {
      body: commands,
    });
    console.log("Đã đăng ký slash commands: /ping, /hello");
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Không thể đăng ký slash commands: ${message}`);
  }
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  if (interaction.commandName === "ping") {
    await interaction.reply(`Pong! Độ trễ: ${client.ws.ping}ms`);
  }

  if (interaction.commandName === "hello") {
    await interaction.reply(`Xin chào ${interaction.user}! Mình đang hoạt động.`);
  }
});

client.on(Events.MessageCreate, (message) => {
  if (message.author.bot) return;

  if (message.content.trim().toLowerCase() === "!hello") {
    void message.reply(`Xin chào ${message.author}! Mình đang hoạt động.`);
  }
});

client.on(Events.Error, (error) => {
  console.error("Discord client error:", error);
});

const shutdown = () => {
  console.log("Đang dừng bot...");
  client.destroy();
};

process.once("SIGINT", shutdown);
process.once("SIGTERM", shutdown);

void client.login(token).catch((error: unknown) => {
  const message = error instanceof Error ? error.message : String(error);
  console.error(`Đăng nhập Discord thất bại: ${message}`);
  process.exitCode = 1;
});